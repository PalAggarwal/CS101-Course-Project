Roll No. - 210260038

Features Implemented - 

1. Required features
  a. Vertical motion of the bubbles, following a parabolic trajectory. The bubbles bounce off from the horizontal ground.
  b. Collision between bullet and bubble. The bubble disappears when hit by the bullet.
  d. Collision between the shooter and the bubble. If the bubble hits the shooter, "Game over" appears on the screen.

2. Extra features
  a. I have used bubbles of larger sizes. When a bullet hits the larger bubbles, they split into smaller bubbles (half the radius of the original larger bubble) and move in 
  horizontally opposite directions.
  b. The game has 3 levels. Once you destroy all the bubbles in one level, you can move to the next level which is difficult in terms of more, faster moving bubbles. Also, the bubbles
  in different levels have different colours.

Once all the bubbles of Level 3 disappear, "Congratulations!! You won" appears on the screen.

GOOGLE DRIVE LINK FOR SCREEN RECORDINGS - https://drive.google.com/drive/folders/1_js-7qJ697Gh2dhDF_YMoE92UfxEfQAh